package org.doit.senti.controller.user;

public class UserSampleController {

}
